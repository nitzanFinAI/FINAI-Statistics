// Navigation between views
const viewButtons = document.querySelectorAll('.nav-btn');
const views = document.querySelectorAll('.view-container');

viewButtons.forEach(button => {
    button.addEventListener('click', () => {
        const targetView = button.getAttribute('data-view');
        
        // Update active button
        viewButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        // Update active view
        views.forEach(view => view.classList.remove('active'));
        document.getElementById(`${targetView}-view`).classList.add('active');
    });
});

// Presentation Slide Navigation
const slides = document.querySelectorAll('.slide');
const prevBtn = document.getElementById('prevSlide');
const nextBtn = document.getElementById('nextSlide');
const currentSlideEl = document.getElementById('currentSlide');
const totalSlidesEl = document.getElementById('totalSlides');

let currentSlide = 1;
const totalSlides = slides.length;

totalSlidesEl.textContent = totalSlides;

function updateSlide() {
    // Hide all slides
    slides.forEach(slide => {
        slide.classList.remove('active');
    });
    
    // Show current slide
    slides[currentSlide - 1].classList.add('active');
    
    // Update counter
    currentSlideEl.textContent = currentSlide;
    
    // Update button states
    prevBtn.disabled = currentSlide === 1;
    nextBtn.disabled = currentSlide === totalSlides;
}

prevBtn.addEventListener('click', () => {
    if (currentSlide > 1) {
        currentSlide--;
        updateSlide();
    }
});

nextBtn.addEventListener('click', () => {
    if (currentSlide < totalSlides) {
        currentSlide++;
        updateSlide();
    }
});

// Keyboard navigation
document.addEventListener('keydown', (e) => {
    const presentationView = document.getElementById('presentation-view');
    
    if (presentationView.classList.contains('active')) {
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
            if (currentSlide < totalSlides) {
                currentSlide++;
                updateSlide();
            }
        } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
            if (currentSlide > 1) {
                currentSlide--;
                updateSlide();
            }
        }
    }
});

// Animate metrics on slide 2
function animateMetricBars() {
    const metricBars = document.querySelectorAll('.metric-bar-fill');
    metricBars.forEach(bar => {
        const width = bar.style.width;
        bar.style.width = '0';
        setTimeout(() => {
            bar.style.width = width;
        }, 100);
    });
}

// Watch for slide changes
const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if (mutation.target.classList.contains('active') && 
            mutation.target.getAttribute('data-slide') === '2') {
            animateMetricBars();
        }
    });
});

slides.forEach(slide => {
    observer.observe(slide, { attributes: true, attributeFilter: ['class'] });
});

// Smooth scroll for one pager
document.addEventListener('DOMContentLoaded', () => {
    // Add smooth scroll behavior
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Animate elements on scroll (for one pager)
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const fadeInObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Apply fade-in animation to cards in one pager
    const cards = document.querySelectorAll('.benefit-card, .service-card, .flow-step, .stat-large');
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        fadeInObserver.observe(card);
    });
});

// Initialize Growth Chart (Slide 2)
function initGrowthChart() {
    const ctx = document.getElementById('growthChart');
    if (!ctx) return;

    // Data from January 2025 to December 2, 2025 (11 months)
    // Showing growth pattern: slow start, strong mid-year, moderate end
    const labels = ['01/01', '01/02', '01/03', '01/04', '01/05', '01/06', 
                    '01/07', '01/08', '01/09', '01/10', '01/11'];
    
    // Realistic cumulative growth - slow start, peak mid-year acceleration
    const data = [78, 134, 217, 348, 542, 798, 1123, 1487, 1782, 1964, 2047];

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'סה"כ לקוחות פעילים',
                data: data,
                borderColor: '#00A8E8',
                backgroundColor: 'rgba(0, 168, 232, 0.25)',
                borderWidth: 5,
                fill: true,
                tension: 0.4,
                pointRadius: 8,
                pointBackgroundColor: '#00A8E8',
                pointBorderColor: '#fff',
                pointBorderWidth: 3,
                pointHoverRadius: 11
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    rtl: true,
                    labels: {
                        font: {
                            size: 16,
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                            weight: '600'
                        },
                        color: '#001F3F',
                        usePointStyle: true,
                        padding: 25
                    }
                },
                tooltip: {
                    rtl: true,
                    backgroundColor: '#001F3F',
                    titleFont: {
                        size: 16,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 15
                    },
                    padding: 14,
                    cornerRadius: 10,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return context.parsed.y.toLocaleString() + ' לקוחות';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'כמות לקוחות',
                        font: {
                            size: 15,
                            weight: 'bold'
                        },
                        color: '#001F3F',
                        padding: 15
                    },
                    grid: {
                        color: 'rgba(0, 31, 63, 0.12)',
                        lineWidth: 1.5
                    },
                    ticks: {
                        font: {
                            size: 14
                        },
                        color: '#5A6C7D',
                        padding: 10,
                        callback: function(value) {
                            return value.toLocaleString();
                        }
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'תאריך (2025)',
                        font: {
                            size: 15,
                            weight: 'bold'
                        },
                        color: '#001F3F',
                        padding: 15
                    },
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            size: 13
                        },
                        color: '#5A6C7D',
                        padding: 8
                    }
                }
            }
        }
    });
}

// Initialize Services Chart (Slide 3)
function initServicesChart() {
    const ctx = document.getElementById('servicesChart');
    if (!ctx) return;

    // Services ordered by size (descending)
    const labels = ['תכנון פיננסי', 'ייעוץ משכנתאות', 'ביטוח בריאות', 
                    'החזרי מס', 'ליווי דירות יד 2', 'ליווי פריסייל'];
    const data = [1247, 945, 823, 612, 534, 387];

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'מספר לקוחות',
                data: data,
                backgroundColor: [
                    'rgba(0, 168, 232, 0.85)',
                    'rgba(0, 168, 232, 0.75)',
                    'rgba(0, 168, 232, 0.65)',
                    'rgba(0, 168, 232, 0.55)',
                    'rgba(0, 168, 232, 0.45)',
                    'rgba(0, 168, 232, 0.35)'
                ],
                borderColor: '#00A8E8',
                borderWidth: 2,
                borderRadius: 10,
                barThickness: 70
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    rtl: true,
                    backgroundColor: '#001F3F',
                    titleFont: {
                        size: 16,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 15
                    },
                    padding: 14,
                    cornerRadius: 10,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return context.parsed.y.toLocaleString() + ' לקוחות';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'מספר לקוחות',
                        font: {
                            size: 15,
                            weight: 'bold'
                        },
                        color: '#001F3F',
                        padding: 15
                    },
                    grid: {
                        color: 'rgba(0, 31, 63, 0.12)',
                        lineWidth: 1.5
                    },
                    ticks: {
                        font: {
                            size: 14
                        },
                        color: '#5A6C7D',
                        padding: 10,
                        callback: function(value) {
                            return value.toLocaleString();
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            size: 13,
                            weight: '600'
                        },
                        color: '#5A6C7D',
                        padding: 10
                    }
                }
            }
        }
    });
}

// Watch for slides to become active and init charts
const slideObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if (mutation.target.classList.contains('active')) {
            const slideNum = mutation.target.getAttribute('data-slide');
            if (slideNum === '2') {
                setTimeout(initGrowthChart, 100);
            } else if (slideNum === '3') {
                setTimeout(initServicesChart, 100);
            }
        }
    });
});

slides.forEach(slide => {
    slideObserver.observe(slide, { attributes: true, attributeFilter: ['class'] });
});

// Initialize
updateSlide();
